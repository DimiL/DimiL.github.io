(function() {
  dump('ERROR\n');
}());
